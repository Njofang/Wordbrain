# <p align="center"> <img src="http://wordbrainsolutions.org/wp-content/uploads/2016/04/wordbrain-answers-1-300x137.png"/> </p> 

Projet Informatique L2 SPI, Université du Maine. 2016-2017.<br/>
Sujet : WordBrain

#Règles du jeu
Votre mission, si vous l'acceptez : Retrouver tous les mots dissimulés dans la grille. <br/><br/>
Le nombre de mots à trouver et leurs tailles vous sont indiqués. 
Quand vous pensez avoir trouvé un mot, vous devez connecter les lettres voisines (dans le bon ordre)  pour former ce mot. 
Lorsque vous avez connecté correctement les lettres d'un mot recherché, ses lettres disparaissent de la grille laissant des trous béants dans celle-ci. 
La nature étant ce qu'elle est, les lettres ayant du vide sous elles tombent (Merci Newton !). <br/>
Prenez garde plus la grille grandit plus la difficulté augmente. <br/>
Un conseil ? La grille ne peux être résolue qu’en trouvant les bonnes lettres des bon mots dans le bon ordre.

#Equipe:

-	Valentin Lion,
-	William Njofang,
-	Gilles Pastouret.


#Come chat on Gitter !

https://gitter.im/WordBrainLeague/Lobby?utm_source=share-link&utm_medium=link&utm_campaign=share-link
