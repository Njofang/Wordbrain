/**
* \file sauvegarde_charge.h
* \brief En-tête des foncions de sauvegarde et recharge.
* \author William NJOFANG
* \version 0.1
* \date nov 18, 2016
*/

#ifndef H_SAUVEGARDE
#define H_SAUVEGARDE


void geneFichierGrille(void);
int recupererDonnees(int ligneFichier);
void ecrireDonnees(void);

/*
void sauvegardegrille(int format);
void chargergrille(int format);
*/

#endif