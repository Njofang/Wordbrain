#ifndef H_GRILLE
#define H_GRILLE

int grilleVide(int format);
void viderGrille(int format);
void rearrangerGrille(int format);

void pickWord(char *mot);
int motPresent(char *mot1);
int supprimerMot(char *mot,const int format);
int alnumtoi(char c);
int coordPresent(int coordonnee);
int caseVide(int coordonnee, int format);
void demanderCoord(int format);

void recupererMots(int niveau, char tabMots[20][TAILLE_MOT_MAX]);
void recupererGrilles(int niveau, char tabGrille[50] );

void formerMot(char motForme[], int format);
void ajouterMot(char *nouvMot);
void initGrille(char *elements,int format);
void initPartie();

#endif