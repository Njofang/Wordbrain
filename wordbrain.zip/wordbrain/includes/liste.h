/**
* \file liste.h
* \brief En-tête des foncions de manipulation de listes.
* \author Pastouret Gilles
* \version 0.1
* \date nov 18, 2016
*/

#ifndef H_LISTE
#define H_LISTE

void init_liste(void);
int liste_vide(void);
int hors_liste(void);

void en_tete(void);
void en_queue(void);
void vider_liste(void);

void precedent(void);
void suivant(void);

void valeur_elt(t_mot *e);
void modif_elt(t_mot e);

void oter_elt(void);
void ajout_droit(t_mot e);
void ajout_gauche(t_mot e);

#endif