/**
* \file wordbrain.h
* \brief En-tête globalisant les definitions d'objets.
* \author Pastouret Gilles
* \version 0.1
* \date nov 20, 2016
*/

#ifndef H_WORDBRAIN
#define H_WORDBRAIN

#define TRUE 1
#define FALSE 0

#define TMAX 7          		/**Taille maximale de la grille*/
#define TAILLE_MOT_MAX 9 		/**Taille maximale d'un mot*/
#define TAILLE_COORD_MAX 25
#define ARGMAXSIZE 256

/**
* \struct t_mot
* \brief Représente les valeurs des éléments de la liste
*/
typedef struct
{
	char mot[TAILLE_MOT_MAX]; 	/*!< Le mot à trouver.*/
	int etat;			/*!< Booléen. Indique si le mot à été trouvé par l'observateur.*/
	int nb_revele;			/*!< Nombre de lettres à montrer a l'utilisateur si il demande des astuces.*/
} t_mot;


/* Variables Globales */
char grille[TMAX][TMAX];
char grilleOri[TMAX][TMAX];
int listeCoord[TAILLE_COORD_MAX];


int format;		/*!< Format de la grille (3 pour une grille 3x3), est utilisé à différentes reprise dans le programme */
int nbCoordonnee;
int nbAstuceUtilise;	/*!< Nombre d'astuces utilisées par l'utilisateur pendant l'execution du programme */
int nbAstuce;		/*!< Nombre d'astuces a disposition */
int nbMots;
int nbMotsVoulus;	/*!< Nombre de mots à récupérer dans le fichier mots.txt pour former la grille */
int score;		/*!< Le score représente le nombre de grille que l'utilisateur a résolu */

int modeDeJeu;

int proposerMot(void);
int verifFinPartie(void);

void astuce(void);
void recommencer(void);
void jouer(int format);
void selectNiv(void);
void menuGrille(void);
void creerGrille(void);

int niveau;		/*!< Niveau (grille) sur lequel l'utilisateur va jouer */

#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>

#include "affichage.h"
#include "liste.h"
#include "grille.h"
#include "sauvegarde_charge.h"




