#ifndef H_GL_MAXI
#define H_GL_MAXI

void menu();
void menuJouer();
void menuJouerP2();
void menuCreerGrille();
void afficherCredit();
void lireFichier();
void menuGrille3x3();
void menuNiveaux(int typeGrille);

#endif
