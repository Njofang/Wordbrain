#ifndef H_AFFICHAGE
#define H_AFFICHAGE

char itoc(int i);
void indenter(int nbIndent);
void afficherGrille(int format);
void afficherEtatMots(void);
void afficherCredits(void);

#endif