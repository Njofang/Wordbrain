#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>



//on defini ici une taille fixe qu on pourra reutiliser
//pour plus de clarte dans le code
#define id_colonne  4
#define id_ligne    4

//on affiche le prototype de la fonction,
//c est a dire sa premiere ligne, pour que le programme
//sache ou aller chercher les fonctions ecrites dans le desordre
void print(char cases[][id_ligne]);
void init(char cases[][id_ligne]);







//debut du programme
int main()
{
    printf(" WORDBRAIN \n\n");

    //j' ai change INT pour CHAR, ca prend moins de place en memoire
    char cases[id_colonne][id_ligne] = {0};
    //j' ai aussi remplace 8 par leur definition plus haut en vert


//j' ai passe trop de temps sur l' initialisation du tableau
//parfois les dernieres cases ne sont pas initialisees, je ne sais pas pkoi
//alors au cas ou j' ai fait une petite fonction
    init(cases);

    //on appelle la fonction d' affichage et on lui envoie le tableau
    print(cases);

    return EXIT_SUCCESS;
}





//initialisation super simple du tableau, 2 boucles.
//attention c' est apres que ca se corse... lol
void init(char cases[][id_ligne])
{
    //char peut contenir de -128 a 128. un int va de -32 000 a 32 000
    char i,j;

    for ( i = 0; i <= id_ligne; i++)
    {
       for( j = 0; j <= id_colonne; j++) cases[i][j] = 0;
    }
}
//pour le tableau on a pas besoin de preciser le nb_colonnes
//je ne sais pas pourquoi ca s' ecrit comme ca,
//j' ai perdu trop de tps dessus, je voulais mettre char** cases,
//finalement !NiCo! m' a donne la solution,
//apparemment le seul moyen de passer un tableau a la fonction d' affichage.






//cette fonction affiche la grille ET les valeurs du tableau
//elle recupere le tableau inscrit dans la RAM
//comme pour init precedemment.
void print(char cases[][id_ligne])
{
    char i,j;

//on va faire 2 passages a chaque fois, un pour afficher les valeurs,
//et un pour les lignes de separation
//et puis on rajoute deux passages pours les bords haut et bas du tableau
    for ( i = 0; i <= ((2 * id_ligne) + 2); i++)
    {

        //on decale le debut de ligne pour ecrire le premier bord GAUCHE,
        printf("\t\t\t");
        //en utilisant le modulo : %
        //il effectue une division puis renvoie LE RESTE et non le resultat
        //ainsi on peut savoir si c' est une ligne paire ou impaire
        //je le reutilise plus loin tu comprendra
        if ( (i % 2) == 0 ) putchar(206);
        else putchar(186);
        //on a dessine, soit un '+' pour les coins,
        // soit un double '|' pour encadrer les chiffres.



        //et c' est parti pour afficher les lignes
        for( j = 0; j <= id_colonne; j++)
        {

            //on va differencier les lignes IMPAIRES (valeurs)
            //et les lignes PAIRES (bordures)

            if ( i % 2 ) // si reste 1, ligne IMPAIRE.
            {
                //on affiche donc les chiffres !
                printf(" %d ", cases[i/2][j]);
                //ici je divise par deux car le nombre de lignes a ete double,
                // pour permettre l affichage des bordures


                //puis le caractere pour encadrer le chiffre
                //si  on en est au 3eme chiffre, j=2 ou 5 ou 8
                //dans tous les cas, si on divise par 3, il reste 2
                //on ferme le bloc sudoku, avec une double barre
                if ( (j % 3) == 2 ) putchar(186);
                else putchar('|');
                //sinon une simple barre "entre chiffre"
            }


            else //cette fois c' est une ligne PAIRE
            {
                if ( (i % 3) == 0) //au bout de 3 lignes ecrites
                {
                    //on affiche soit "===+" pour les coins de blocs sudoku
                    if ( (j % 3) == 2 ) printf("%c%c%c%c", 205, 205, 205, 206);
                    //soit "====" pour l' interieur des cadres de blocs
                    else printf("%c%c%c%c", 205, 205, 205, 205);
                }
            //si on est pas au bout de 3 lignes, alors c' est pas un bloc
            //MAIS SI on est au troisieme chiffre, il ya un bord VERTICAL double
                else if ( (j % 3) == 2 ) printf("---%c", 206);
                //sinon, entre chiffres, affiche simplement "---+"
                else printf("---%c", 197); // 197 est un '+' agrandi
            }
        }
        putchar('\n');
        //et hop la ligne est terminee
    }

    //bin.. voila, ca y est c est fini.
}
