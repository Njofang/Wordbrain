/**
* \file liste.c
* \brief Primitives de manipulation de listes.
* \author Pastouret Gilles
* \version 0.1
* \date nov 18, 2016
*/

#include "../includes/wordbrain.h"



/**
* \struct t_element
* \brief Représente les éléments de la liste
*/
typedef struct element 
{
	t_mot valeur;			/*!< Structure composée du mot et son état.*/
	struct element *succ;	/*!< Pointeur sur l'élément suivant.*/
	struct element *pred;	/*!< Pointeur sur l'élément précédent.*/
} t_element;

t_element *drapeau;
t_element *ec;



/**
* \fn void init_liste(void)
* \brief Initialise la liste à vide.
*/
void init_liste(void)
{	
	drapeau = malloc(sizeof(t_element));
	
	drapeau->pred = drapeau;
	drapeau->succ = drapeau;
	
	ec = drapeau;
	
	nbMots=0;
}

/**
* \fn int liste_vide(void)
* \return Vrai si la liste est vide, faux sinon.
*/
int liste_vide(void)
{	
	return (drapeau->succ == drapeau);
}

/**
* \fn int hors_liste(void)
* \return Vrai si l'élément courant est hors de la liste, faux sinon.
*/
int hors_liste(void)
{	
	return (ec == drapeau);
}


/*------------------------------------------------------*/

/**
* \fn void en_tete(void)
* \brief Positionne l'élément courant en tete de la liste.
*/
void en_tete(void)
{	
	if(!liste_vide()) 
		ec = drapeau->succ;
}

/**
* \fn void en_queue(void)
* \brief Positionne l'élément courant en queue de la liste.
*/
void en_queue(void)
{	
	if(!liste_vide()) 
		ec = drapeau->pred;
}

/**
* \fn void vider_liste(void)
* \brief Vide la liste.
*/
void vider_liste(void)
{
	en_queue();
	while(!hors_liste())
		oter_elt();
}

/*------------------------------------------------------*/

/**
* \fn void precedent(void)
* \brief Positionne l'élément courant sur le précédent élément si ce premier n'est pas hors-liste.
*/
void precedent(void)
{	
	if(!hors_liste()) 
		ec = ec->pred;
}

/**
* \fn void suivant(void)
* \brief Positionne l'élément courant sur l'élément suivant si ce premier n'est pas hors-liste.
*/
void suivant(void)
{	
	if(!hors_liste()) 
		ec = ec->succ;
}


/*------------------------------------------------------*/

/**
* \fn void valeur_elt(t_mot *e)
* \brief Renvoie dans e la valeur de l'élément courant si celui-ci n'est pas hors-liste.
* 
* \param e Pointeur sur un objet de type t_mot.
* \return Valeur de l'elt courant de type t_element ou rien.
*/
void valeur_elt(t_mot *e)
{	
	if(!hors_liste()) 
		*e = ec->valeur;
}

/**
* \fn void modif_elt(t_mot e)
* \brief Affecte e à la valeur de l'élément courant si celui-ci n'est pas hors-liste.
* 
* \param e Objet de type t_mot.
*/
void modif_elt(t_mot e)
{	
	if(!hors_liste()) 
		ec->valeur = e;
}


/*------------------------------------------------------*/


/**
* \fn void oter_elt(void)
* \brief Supprime l'élément courant de la liste si celui-ci n'est pas hors-liste.
*/
void oter_elt(void)
{	
	t_element *suppr;
	if(!hors_liste())
	{	
		ec->succ->pred = ec->pred;
		ec->pred->succ = ec->succ;
		
		suppr = ec;
		ec = ec->pred;
		free(suppr);
	}
}

/**
* \fn void valeur_elt(t_mot *e)
* \brief Ajoute la valeur e à droite de l'elt courant.
* 
* \param e Objet de type t_mot.
*/
void ajout_droit(t_mot e)
{
	t_element *nouv;	
	nouv = malloc(sizeof(t_element));
	
	nouv->pred = ec;
	nouv->succ = ec->succ;
	
	ec->succ->pred = nouv;
	ec->succ = nouv;
	
	nouv->valeur = e;
}

/**
* \fn void valeur_elt(t_mot *e)
* \brief Ajoute la valeur e à gauche de l'elt courant.
* 
* \param e Objet de type t_mot.
*/
void ajout_gauche(t_mot e)
{	
	t_element *nouv;
	nouv = malloc(sizeof(t_element));
	
	nouv->succ = ec;
	nouv->pred = ec->pred;
	
	ec->pred->succ = nouv;
	ec->pred = nouv;
	
	nouv->valeur = e;
}



