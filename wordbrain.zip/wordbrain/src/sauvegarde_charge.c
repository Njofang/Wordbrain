/**
* \file grille.c
* \brief Fonctions de sauvegarde et recharge de la grille.
* \author William NJOFANG
* \version 0.1
* \date nov 16, 2016
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../includes/wordbrain.h"

FILE*fichier=NULL;



/**
* \fn void geneFichierGrille(void)
* \brief Genere les grilles et les sauvegarde dans le fichier grilles2.txt
*
*/
void geneFichierGrille(void)
{
	FILE* fichier;
	int niveau=1;
	int form;

	char tab[20][TAILLE_MOT_MAX];

	fichier=fopen("grilles2.txt", "w");
	

	
	while(niveau<=18)
	{
	
		// Obtentino du format
		form=((niveau-1)/3)+2;

		// On recupere les mots
		recupererMots(niveau,tab);

		// On genere la grille
		// ...

		// On écrit la grille dans le fichier
		for(int i=0; i<form; i++)
			for(int j=0; j<form; j++)
				fprintf(fichier,"%c",grille[i][j]);

		// On passe au prochain niveau
		fprintf(fichier,"\n");
		niveau++;
	}


	fclose(fichier);

}


/**
* \fn int recupererDonnees(int ligneFichier)
* \brief Permet de reécuper les données du fichier vars.txt
*
* \param Ligne à laquelle le programme va chercher la valeur
*
* \return la donnée cherché a la ligne mise en paramètre
*/
int recupererDonnees(int ligneFichier)
{
	int recup;
	int ligne=1;
	
	char cara;

	FILE* fic1;	
	
	// Ouverture du fichier en lecture	
	fic1 = fopen("vars.txt","r");

	// Se positionne a la ligne correspondant au niveau (une ligne = un niveau)
	while(ligne<ligneFichier)
	{
	
		cara=fgetc(fic1);
        	if (cara=='\n')
        	        ligne++;
	}		

	// On recupere la grille
	fscanf(fic1,"%i",&recup);
	
	
	fclose(fic1);
	
	return recup;
}



/**
* \fn void ecrireDonnees(void)
* \brief Enregistre les données dans le fichier vars.txt
*
*/
void ecrireDonnees(void)
{
	FILE* fic1;	

	fic1=fopen("vars.txt", "w");
	
	// Ecriture du nombre d'astuces restantes
	fprintf(fic1,"%i",nbAstuce-nbAstuceUtilise);
	fprintf(fic1,"\n");
	// Ecriture du score
	fprintf(fic1,"%i",score);
	fprintf(fic1,"\n");

	fclose(fic1);			
}












/*
void sauvegardegrille(int format){
	
	fichier=fopen("donnees.txt", "w");
	
	int form=0;
	int i,j;
	
	if(!grilleVide(format))
		for(i=0; i<format; i++){
			for(j=0; j<format; j++){
			
				fprintf(fichier,"%c",grille[i][j]);
				
				if(form==format){
					fprintf(fichier,"\n");}
				form++;		
			}
	
		}
	fclose(fichier);			
}


void chargergrille(int format){
	
	fichier=fopen("donnees.txt", "r");
	
	int i,j;
	char c;
	int form=0;
	
	if(grilleVide(format))
		for(i=0; i<format; i++){
			for(j=0; j<format; j++){
			
				fscanf(fichier,"%c", &c);
				strcpy(&grille[i][j], &c);
				
				if(form==format){
					fscanf(fichier,"\n");}
				form++;		
			}
	
		}

	fclose(fichier);	
}
*/





