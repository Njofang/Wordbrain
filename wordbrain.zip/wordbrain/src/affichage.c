/**
* \file affichage.c
* \brief Fonctions d'affichage pour les différentes interfaces.
* \author Pastouret Gilles
* \version 0.1
* \date nov 19, 2016
*/

#include "../includes/wordbrain.h"



/**
* \fn char itoalpha(int i)
* \brief Integer to alphabetic.
* 
* Prend un entier et renvoie une lettre majuscule. 0=A, 1=B, 2=C, etc...
* 
* \param i Un entier allant de 0 à 23.
* \return Un caractère, essentiellement une lettre majuscule.
*/
char itoalpha(int i)
{
	char c;
	c = ('A' + i);
	return c;
}



/**
* \fn void indenter(int nbIndent)
* \brief Affiche des espaces pour décaler l'affichage d'une ligne, equivalent a un alinéa.
* 
* \param nbIndent Un entier correspondant au nombre de décalage à effectuer.
*/
void indenter(int nbIndent)
{
	for(int i=0; i<nbIndent; i++)
		printf("    ");
}



/**
* \fn void afficherGrille(int format)
* \brief Affiche une partie de la grille en fonction du format reçu.
* 
* Le format reçu ne peut excéder le format maximal de la matrice (soit TMAX).
* 
* \param grille Une matrice carrée de format maximal TMAX x TMAX.
* \param format Le format de la matrice à afficher.
*/
void afficherGrille(int format)
{
	int i,j,k;
	char lettre;
	
	if(format > TMAX) format = TMAX;
	
	printf("\n");
	indenter(2);
	for(i=1; i <= format; i++)
		printf("  %i ",i);
	printf("\n");
	indenter(2);
	for(k=0; k <= 4*format; k++) 	// On multiplie l'affichage des '-' par 4 
		printf("-");		// car pour chaque colonne on a 4 caractère.
	printf("\n");
	
	for(i=0; i<format; i++)
	{
		indenter(1);
		lettre = itoalpha(i);
		printf("%c   |",lettre);
		for(j=0; j<format; j++)
		{
			printf(" %c |",grille[i][j]);
		}
		
		printf("\n");
		indenter(2);
		for(k=0; k <= 4*format; k++)
			printf("-");
		printf("\n");
	}
}

/**
* \fn void afficherEtatMots(void)
* \brief Affiche la liste de mots à trouver.
* 
* Les lettres de mots seront cachées ou révélées selon que le mot ait été trouvé pour pas et selon le nombre d'indices utilisés.
*/
void afficherEtatMots(void)
{
	t_mot e;
	int i;

	en_tete();

	while(!hors_liste())
	{
		indenter(1);
		valeur_elt(&e);
		
		printf("+ ");
		for(i=0; e.mot[i] != '\0'; i++)
		{
			if( i < e.nb_revele)
				printf("%c",e.mot[i]);
			else
				printf("%c",'.');
		}
		if(e.etat == TRUE)
			printf("* trouvé !");
		printf("\n");
		suivant();
	}
	printf("\n");
}


/**
* \fn void afficherCredit(void)
* \brief Affiche les crédits du programme et attend que la touche entrée soit tapé. 
*/
void afficherCredits(void)
{
	/* Choix de l'utilisateur */
	char c;
		
	system("clear");
	/* Affichage du menu */
	printf("\nWordBrain :\n\n");
	printf("Jeu développé par:\n\n   Gilles Pastouret\n   William Njofang\n   Valentin Lion\n\n");
	printf(" Appuyez sur Entrer pour retourner au menu.\n\n");
	
	c = getchar();
	while(c != '\n');
		c = getchar();

}

/**
* \fn void afficherCredit(void)
* \brief Affiche les crédits
* 
*/
/*
void afficherCredits(void)
{
	
	int choix;
	do
	{
		system("clear");
		// Affichage du menu 

		printf("\n WordBrain :\n\n");
		printf("Jeu développé par:\n\n   Gilles Pastouret\n   William Njofang\n   Valentin Lion\n\n");
		printf("1 - Quitter.\n");
		scanf("%i",&choix);

	}while(choix!=1);

}
*/


