#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "biblio.h"
#define TMAX 7
#define TMOTMAX 8

int nbAstuces=6;
int indiceAstuce=0;

char nom_fichier[20];

 
typedef struct {int x;int y;} t_coord;



void menuJouer(){
		
	int choix;	/* Choix de l'utilisateur */

	do{
		system("clear");
		/* Affichage du menu */
		printf("\n Taille de Grille :\n\n");
		printf(" 1 - 2x2\n");
		printf(" 2 - 3x3\n");
		printf(" 3 - 4x4\n");
		printf(" 4 - page suivante\n");
		printf(" 5 - Retour\n\n");
		printf("Votre choix : ");
		scanf("%i",&choix);		
		
		
		/* Traitement du choix de l'utilisateur */
		switch(choix)
		{	case 1:  break;
			case 2:  menuNiveaux(3); break;
			case 3:  break;
			case 4:  menuJouerP2(); break;
			case 5:  menu(); break;
			default: printf("Erreur: votre choix doit etre compris entre 1 et 5\n");
		}
		
	}while(choix>5 || choix<1);

}


void menuJouerP2(){
	
	int choix;	/* Choix de l'utilisateur */

	do{
		system("clear");
		/* Affichage du menu */
		printf("\n Taille de Grille :\n\n");
		printf(" 1 - 5x5\n");
		printf(" 2 - 6x6\n");
		printf(" 3 - 7x7\n");
		printf(" 4 - page precedente\n\n");
		printf("Votre choix : ");
		scanf("%i",&choix);		
		
		
		/* Traitement du choix de l'utilisateur */
		switch(choix)
		{	case 1:  break;
			case 2:  break;
			case 3:  break;
			case 4:  menuJouer(); break;
			default: printf("Erreur: votre choix doit etre compris entre 1 et 4\n");
		}
			
	}while(choix>4 || choix<1);
		
}

void menuNiveaux(int typeGrille)
{	
	int choix;	/* Choix de l'utilisateur */

	do{
		system("clear");
		/* Affichage du menu */
		printf("\n Choix du niveau :\n\n");
		printf(" 1 - Niveau 1\n");
		printf(" 2 - Niveau 2\n");
		printf(" 3 - Niveau 3\n");
		printf(" 4 - Retour\n");
		printf("Votre choix : ");
		scanf("%i",&choix);
		
		
		/* Traitement du choix de l'utilisateur */
		if(typeGrille==2)
			{switch(choix)
			{	case 1:  jouer(typeGrille); break;
				case 2:  break;
				case 3:  break;
				case 4:  break;
				default: printf("Erreur: votre choix doit etre compris entre 1 et 6\n");
			}
		}
		else if(typeGrille==3)
		{	switch(choix)
			{	case 1:  jouer(typeGrille); break;
				case 2:  break;
				case 3:  break;
				case 4:  break;
				default: printf("Erreur: votre choix doit etre compris entre 1 et 6\n");
			}
		}
		else if(typeGrille==4)
		{
		}
		else if(typeGrille==5)
		{
		}
		else if(typeGrille==6)
		{
		}
		else if(typeGrille==7)
		{
		}
		
		switch(choix)
		{	case 1:  menuGrille3x3(); break;
			case 2:  break;
			case 3:  break;
			case 4:  break;
			case 5:  break;
			case 6:  menuJouer(); break;
			default: printf("Erreur: votre choix doit etre compris entre 1 et 6\n");
		}
			
	}while(choix>6 || choix<1);
	
}






void lireFichier(){

	int i=0;
	int j=0;
	int espace=0;
	int rl=0;
	char cara;
	FILE* fic1;
	
	char tab[10][4];
	
	scanf("%s",nom_fichier);
	
	fic1 = fopen(nom_fichier,"r");
	
	
	fscanf(fic1,"%c",&cara);
	while(!(feof(fic1)) && cara!='.')
	{
		/*i++;
		
		switch(cara)
		{
			case '\n' : rl++;
			case ' ' : espace++;
		}*/
		
		while(cara!='\n')
		{
			
			tab[i][j]=cara;
			fscanf(fic1,"%c",&cara);
			j++;
		}
		printf("test");
		fscanf(fic1,"%c",&cara);
		
		i++;
			
	}
	
	//printf("Mots:%i Retour a la ligne:%i \n",espace+1,rl);
	
	for(int k=0; k<10; k++){
			for(int l=0; l<4; l++){
				printf("%c",tab[k][l]);
			}
			printf("\n");
	}

	fclose(fic1);
}



/*Exemple de Base pour les grilles

	printf("\t      1   2   3       \n");
	printf("\t    -------------     \n");
	printf("\t A  | V | A | L |     \n");
	printf("\t    -------------     \n");
	printf("\t B  | J | E | L |     \n");
	printf("\t    -------------     \n");
	printf("\t C  | B | R | L |     \n");
	printf("\t    -------------     \n\n");
*/


void menuGrille3x3(){

	

	int cpt=0;
	int tGrille=3;
	int choix;

	char tabMD[2][5]={'-','-','-','-','-' , '-','-','-','-','-'};


	// genereeGrille(char tab[TMAX][TMAX],3)
	// Alternative temporaire a la genération auto

	char tab[3][3]={'L','T','E',
			'I','A','R',
			'V','I','T'};
	
	t_mot motUtilises[2];
	motUtilises[0].etat=0;
	strcpy(motUtilises[0].tabMot,"LAIT");
	motUtilises[0].etat=0;
	strcpy(motUtilises[1].tabMot,"VITRE");


	
		do{
			system("clear");
		      printf("\n\t      WordBrain       \n\n");

			printf("\t      1   2   3       \n");
			printf("\t    -------------     \n");
			printf("\t A  | %c | %c | %c |  \n",tab[0][0],tab[0][1],tab[0][2]);
			printf("\t    -------------     \n");
			printf("\t B  | %c | %c | %c |  \n",tab[1][0],tab[1][1],tab[1][2]);
			printf("\t    -------------     \n");
			printf("\t C  | %c | %c | %c |  \n",tab[2][0],tab[2][1],tab[2][2]);
			printf("\t    -------------     \n\n");

			
			
			//To do:
			//Si un mot est trouvé, l'afficher
			//Utilisation du champ etat de la structure

			printf("\t   Mots à trouver:  \n");
			printf("\t     %c%c%c%c  %c%c%c%c%c    \n\n",
			tabMD[0][0],tabMD[0][1],tabMD[0][2],tabMD[0][3],tabMD[1][0],tabMD[1][1],tabMD[1][2],tabMD[1][3],tabMD[1][4]);


			printf(" 1 - Proposer un mot    \n");
			printf(" 2 - Recommencer        \n");
			printf(" 3 - Demander une astuce\n");
			printf(" 4 - Quitter            \n\n");
			printf("Votre choix : ");  

			scanf("%i",&choix);

			switch(choix)
			{	case 1:  break;
				case 2:  break;

				// Montre les premieres lettres des mots alternativement
				// Et incrémente le nb d'astuces utilisées
				// Jusqu'au seuil limite nbAstuces
				case 3:  if(indiceAstuce<nbAstuces){
						tabMD[indiceAstuce%2][cpt] = motUtilises[indiceAstuce%2].tabMot[cpt];						
					 }					 
					 indiceAstuce++;
					 if(indiceAstuce%2==0) cpt++; break;
				case 4:  menu(); break;
				default: printf("Erreur: votre choix doit etre compris entre 1 et 4\n");
			}

		}while(choix!=4);
}




///////////////////////// WORK IN PROGRESS /////////////////////////


/*
Code pour "recommencer" le niveau:
	
	//Reset les mots donnés par l'utilisateur
	for(int i=0; i<nbMots;i++)
		for(int j=0; j<TMOTMAX; j++)		
			tabMD[][]='-';

	//Etat 0: mot non trouvé
	for(int i=0; i<nbMots; i++)
	{
		motUtilises[i].etat=0;
	}
	
*/




/*Forme un mot à partir de coordonnées
void formerMot(t_coord tabCoord[TMOTMAX])
{
	int taille=strlen(tabCoord);

	char tabMotProp[TMOTMAX];
	
	for(int i=0; i<taille; i++)
		tabMotProp=tab[tabCoord[i].y][tabCoord[i].x];

}

*/


/* Retourn l'indice du mot si le mot proposé est bon et -1 sinon
int verifierMot()
{
	char tabMotProp[TMOTMAX];
	scanf("%s",tabMotProp);

	int check=0;

	for(int i=0; i<nbMots; i++)	
	{
		if(strcmp(tabMotProp,motUtilises[i])==0)
		{	check=1;
			motUtilises[indice].etat=1;
			return indice;
		}
	}
	return check;	
}
*/

