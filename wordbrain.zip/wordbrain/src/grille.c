/**
* \file grille.c
* \brief Fonctions de manipulation de grille.
* \author Pastouret Gilles & Valentin Lion
* \version 0.1
* \date nov 16, 2016
*/


#include "../includes/wordbrain.h"



/**
* \fn void recupererMots(int niveau, char tabMots[])
* \brief Assigne dans un tableau les mots récupérer du fichier correspondant au niveau donné.
*
* \param Le niveau pour lequel on recupère les mots.
* \param Le tableau dans lequel on stocke les mots.
*/
void recupererMots(int niveau, char tabMots[20][TAILLE_MOT_MAX] )
{
	
	int ligne=1;
	int condition=0;
	int i=0;
	
	char cara;
	char tab[20][TAILLE_MOT_MAX];

	FILE* fic1;	
	
	// Ouverture du fichier en lecture	
	fic1 = fopen("mots.txt","r");

	// Se positionne a la ligne correspondant au niveau (une ligne = un niveau)
	while(ligne<niveau)
	{
	
		cara=fgetc(fic1);
        	if (cara=='\n')
        	        ligne++;
	}		

	// Dans le fichier on recupere le nombre de mots se trouvant sur la ligne
	fscanf(fic1,"%s",tab[0]);
	nbMotsVoulus=atoi(tab[0]);
	
	// On s'arrete si fin de fichier ou après avoir récupérer nbMotsVoulus mots
	while(!(feof(fic1)) && condition!=1)
	{	
		//On recupère le(s) mot(s)
		fscanf(fic1,"%s",tab[i+1]);		
		strcpy(tabMots[i],tab[i+1]);
		// On incrémente le nombre de mots récupérés
		i++;	
		
		// Une des Conditions de sortie
		if(i==nbMotsVoulus)
			condition=1;			
	}	
	fclose(fic1);
}



/**
* \fn void recupererGrilles(int niveau, char tabGrille[50] )
* \brief Récupère la grille stocké dans le fichier grilles.txt
*
* \param Le niveau pour lequel on recupère la grille.
* \param Le tableau dans lequel on stocke la grille.
*/
void recupererGrilles(int niveau, char tabGrille[50] )
{
	int nbMotsVoulus;
	int ligne=1;
	int condition=0;
	int i=0;	
	char cara;

	FILE* fic1;	
	
	// Ouverture du fichier en lecture	
	fic1 = fopen("grilles.txt","r");

	// Se positionne a la ligne correspondant au niveau (une ligne = un niveau)
	while(ligne<niveau)
	{
	
		cara=fgetc(fic1);
        	if (cara=='\n')
        	        ligne++;
	}		

	// On recupere la grille
	fscanf(fic1,"%s",tabGrille);
	
	
	fclose(fic1);
}


/**
* \fn void formerMot(char *motForme,int format)
* \brief Forme un mot à partir des coordonnées contenus dans la liste de coordonnées.
*
* \param motForme Chaîne de caractère acceillant le mot formé. 
* \param format Entier correspondant au format de la grille.
* \return Une chaine de caractère.
*/
void formerMot(char *motForme,int format)
{
	int i=0;
	int j=0;
	int x,y;
	
	//Construction du mot
	for(i=0; i<nbCoordonnee; i++)
	{
		x = listeCoord[i]%format;
		y = (int) listeCoord[i]/format;
		motForme[i]=grille[x][y];
	}
	motForme[i] = '\0';
	printf("Tentative : %s \n",motForme);
	sleep(1);
}

/**
* \fn int grilleVide(int format)
* \brief Indique si la grille du format donné est vide.
*
* \param format Entier correspondant au format de la grille.
* \return Booléen valant vrai si la grille est vide, faux sinon.
*/
int grilleVide(int format)
{	
	int i,j;
	for(i=0; i<format; i++)
	{
		for(j=0; j<format; j++)
		{
			if(grille[i][j] != ' ')
				return 0;
		}
	}
	return 1;	 
}

/**
* \fn void viderGrille(int format)
* \brief Vide la grille du format donné.
*
* \param Format Entier correspondant au format de la grille.
*/
void viderGrille(int format)
{
	int i,j;
	for(i=0; i<format; i++)
	{
		for(j=0; j<format; j++)
		{
			grille[i][j]=' ';
		}
	}
}

/**
* \fn void rearrangerGrille(int format)
* \brief Réarrange les lettres de la grille en comblant les vides.
* 
* Les lettres seront déplacées vers les cases en-dessous d'elles jusqu'à ce qu'il n'y ait plus de vide sous aucune lettre.
* \param Format Entier correspondant au format de la grille.
*/
void rearrangerGrille(int format)
{	
	int i,j,k;
	for(j=0; j<format; j++)
	{
		for(i=format-1; i>0; i--) //La première ligne n'est pas traitée.
		{
			if(grille[i][j] == ' ')
			{	k=1;
				do{
					if(grille[i-k][j] != ' ')
					{
						grille[i][j] = grille[i-k][j];
						grille[i-k][j] = ' ';
						break;
					}
					k++;
				}while(i-k >= 0);
			}
		}
	}		 
}


/**
* \fn void pickWord(char *mot)
* \brief Récupère le mot de l'élément courant de la liste.
* 
* Il ne se passe rien si l'élément courant est hors liste.
*
* \param mot Chaîne de caractère acceillant le mot récupéré.
* \return Une chaine de caractère.
*/
void pickWord(char *mot)
{
	t_mot structMot;
	if(!hors_liste())
	{
		valeur_elt(&structMot);
		strcpy(mot,structMot.mot);
	}
}

/**
* \fn void pickWord(char *mot)
* \brief Indique si le mot est présent dans la liste de mos à touver.
* 
* Si le mot est présent alors l'élément courant est placé dessus sinon il est hors liste.
*
* \param mot1 Chaîne de caractère à comparer avec les éléments de la liste.
* \return Booléen valant vrai si le mot est présent, faux sinon.
*/
int motPresent(char *mot1)
{
	char mot2[TAILLE_MOT_MAX];
	
	en_tete();
	while(!hors_liste())
	{
		pickWord(mot2);
		if(strcmp(mot1,mot2) == 0)
			return TRUE;
		else
			suivant();
	}
	return FALSE;
}

/**
* \fn void ajouterMot(char *nouvMot)
* \brief Ajoute un mot à la liste des mots à trouver.
* 
* Ajoute le mot et initialise les différents états de ce mot.
*
* \param nouvMot Chaîne de caractère à ajouter à la liste.
*/
void ajouterMot(char *nouvMot)
{
	t_mot nouv;
	strcpy(nouv.mot, nouvMot);
	nouv.etat = FALSE;
	nouv.nb_revele = 0;
	
	ajout_droit(nouv);	
	nbMots++;
}

/**
* \fn int supprimerMot(char *mot,const int format)
* \brief Indique le mot comme trouvé s'il appartient à la liste des mots à trouver.
*
* \param mot Chaine de caractère correspondant au mot à supprimer
* \param format Entier correspondant au format de la grille.
* \return Booléen valant vrai si la modification a bien été effectuée.
*/
int supprimerMot(char *mot,const int format)
{
	t_mot structMot;
	int x,y;
	
	if(motPresent(mot))
	{
		valeur_elt(&structMot);
		if(structMot.etat != TRUE)
		{
			structMot.etat = TRUE;
			structMot.nb_revele = strlen(mot);
			modif_elt(structMot);
			
			for(int i=0; i<nbCoordonnee; i++)
			{
				x = listeCoord[i]%format;
				y =(int) listeCoord[i]/format;
				grille[x][y] = ' ';
			}
			
		}else
		{
			printf("Ce mot est déjà trouvé\n");
			sleep(1);
			return FALSE;
		}
	}else 
	{
		printf("Ce mot n'est pas à trouver\n");
		sleep(1);
		return FALSE;
	}
	return TRUE;
}

/**
* \fn int alnumtoi(char c)
* \brief Transforme un caractère alphabétique ou numérique en entier.
* 
* Prend une lettre ou un chiffre et renvoie l'entier correspondant. 
* 
* \param c Un caractère
* \return Un entier.
*/
int alnumtoi(char c) //alphanumeric to integer
{
	int i;
	
	if(isdigit(c))
	{
		i = c - '0';
	}
	else if(isalpha(c))
	{
		if(islower(c))
			i = c - 'a';
		else if(isupper(c))
			i = c - 'A';
	}
	
	return i;
}

/**
* \fn int coordPresent(int coordonnee)
* \brief Vérifie si le numéro de case donné se trouve dans la liste de coordonées.
* 
* \param coordonnee Entier représentant le numéro de case (la coordonnée).
* \return Booléen valant vrai si la coordonnée est présente dans la liste, faux sinon.
*/
int coordPresent(int coordonnee)
{
	int i;
	for(i=0; i<nbCoordonnee; i++)
	{
		if(listeCoord[i] == coordonnee)
			return 1;
	}
	return 0;
}

/**
* \fn int caseVide(int coordonnee, int format)
* \brief Indique si la case est vide.
* 
* \param coordonnee Entier représentant le numéro de case (la coordonnée).
* \param format Entier correspondant au format de la grille.
* \return Booléen valant vrai si la case est vide, faux sinon.
*/
int caseVide(int coordonnee, int format)
{
	int x,y;
	x = coordonnee%format;
	y = (int) coordonnee/format;
	
	return (grille[x][y] == ' ');
}

/**
* \fn void demanderCoord(int format)
* \brief Procédure de vérification et de formatage de l'entrée des coordonées.
* 
* Les coordonnées sont ensuite rangé dans la liste de coordonnées.
* 
* \param format Entier correspondant au format de la grille.
*/
void demanderCoord(int format) //Cette fonction est clairement à améliorer
{	
	char entree[3];
	nbCoordonnee = 0; //global var
	int formatValide = FALSE;
	int new_x, new_y, last_x, last_y, diff_x, diff_y;
	int existsOldCoord = FALSE, liaisonOk;
	int coord;
	
	printf("Entrez les coordonnées de lettres dans le bon ordre pour former un mot.\n");
	printf("terminez votre entrée par #)\n");
	fflush(stdin);
	scanf("%s",entree);
	while(strcmp(entree,"#")!=0)
	{
		formatValide = (strlen(entree)==2 && isalpha(entree[0]) && isdigit(entree[1]));
		if(!formatValide)
			printf("Format de coordonnées invalide (%s). Usage : [A-J][0-9]\n(tapez # pour terminer)\n",entree);
		else
		{
			new_x = alnumtoi(entree[0]);
			new_y = alnumtoi(entree[1])-1; // On retire 1 car les abscisses implémentées commencent à 0 alors que celles affichées commencent à 1.
			
			if(new_x>=0 && new_x<format && new_y>=0 && new_y<format)
			{
				if(existsOldCoord)
				{
					diff_x = new_x - last_x;
					diff_y = new_y - last_y;
					liaisonOk = diff_x>=-1 && diff_x<=1 && diff_y>=-1 && diff_y<=1;
				}
				else
					liaisonOk = TRUE;
				
				if(liaisonOk){
					coord = new_y*format + new_x;
					if(!coordPresent(coord) && !caseVide(coord,format))
					{
						listeCoord[nbCoordonnee] = coord;
						nbCoordonnee ++;
				
						last_x = new_x;
						last_y = new_y;
						existsOldCoord = TRUE;
					}
					else
						printf("Sélection incorrecte (%s): Vous avez entré deux fois les mêmes coordonnées ou avez sélectionné une case vide.\n",entree);
				}
				else
					printf("Sélection incorrecte (%s): Une case sélèctionnée doit être à côté de la case précédemment sélectionnée\n",entree);
			}else
				printf("Coordonnées invalides (%s). Tentative d'accès à une valeur hors grille.\n",entree);
		}
		scanf("%s",entree);
	}
}





void initGrille( char *elements,int format)
{
	int i,j;
	int finTab = FALSE;
	for(i=0; i<format && !finTab; i++)
		for(j=0; j<format && !finTab; j++)
			if(elements[i+j] != '\0')
			{
				grille[i][j] = elements[i*format+j];
				grilleOri[i][j] = elements[i*format+j];	
			}else
				finTab = TRUE;
}

void initPartie() 
{
	vider_liste();
	viderGrille(TMAX);

	char tabMots[20][TAILLE_MOT_MAX];
	char tabGrille[50];
	modeDeJeu=1;

	recupererMots(niveau,tabMots);
	recupererGrilles(niveau,tabGrille);
	
	initGrille(tabGrille,format);


	for(int i=0; i<nbMotsVoulus; i++)
		ajouterMot(tabMots[i]);

	jouer(format);
	
}


