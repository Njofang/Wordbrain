/**
* \file main.c
* \brief Programme principal
* \author Valentin Lion & Pastouret Gilles & William Njofang
* \version 0.1
* \date nov 18, 2016
*/

/*! \mainpage Bienvenue
 *
 * \section intro_sec Règles du wordbrain:
 *
 *
 * Retrouver tous les mots de la grille. Le nombre de mots à trouver et leur taille est indiqué au joueur, ainsi que les mots trouvés et ceux restant. La grille ne peux être résolue qu’en trouvant les mots dans le bon ordre.
 * Quand le joueur a trouvé un mot, il doit le former en liant les lettre dans le bon ordre que ce soit verticalement, horizontalement ou encore diagonalement.
 * La difficulté des grilles croît avec la progression du joueur. Cette difficulté est notamment liées à la taille de la grille et au nombre de mots enchevêtrés.
 * Lorsque le joueur forme un mot et que celui-ci fait parti de la liste des mots à trouver, ses lettres disparaissent laissant des trous dans la grille.
 * Toutes les lettres subissent un effet de "chute". Autrement dit, si une lettre se trouve au-dessus d’une case vide elle descend de case en case jusqu’à rencontrer une case pleine (sur laquelle elle ne se superposera pas).
 * La grille peut être recommencée autant de fois que le joueur le décide.
 *
 * Bonus : Le joueur peut obtenir une aide s’il reste bloqué. (Reste à déterminer quel type d’aide et sous quelles conditions)
 *
 */

#include "../includes/wordbrain.h"



int main()
{
	int choix;	/* Choix de l'utilisateur */
	init_liste();

	nbAstuceUtilise=0;

	viderGrille(TMAX);

	nbAstuce = recupererDonnees(1);
	score = recupererDonnees(2);

	do{

		system("clear");
		/* Affichage du menu */

		printf("\n WordBrain :\n\n");
		printf(" 1 - Jouer\n");
		printf(" 2 - Créer une grille\n");
		printf(" 3 - Crédit\n");
		printf(" 4 - Quitter\n\n");
		printf("Votre choix : ");
		
		fflush(stdin);
		scanf("%i",&choix);		
		
		/* Traitement du choix de l'utilisateur */
		switch(choix)
		{	case 1:  menuGrille(); break;
			case 2:  creerGrille(); break;
			case 3:  afficherCredits(); break;
			case 4:  break;
			default: printf("Erreur: votre choix doit etre compris entre 1 et 4.\n");
		}
	
	}while(choix!=4);
	

	//Réécrire dans le fichier vars.txt les nouvelles valeurs des variables (ex: nbAstuce)
	ecrireDonnees();

	printf("\nAu revoir !\n\n");
	exit(EXIT_SUCCESS);
}