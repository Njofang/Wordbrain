/**
* \file wordbrain.c
* \author Valentin Lion & Pastouret Gilles
* \version 0.1
* \date nov 20, 2016
*/

#include "../includes/wordbrain.h"


/**
* \fn int proposerMot(void)
* \brief Procédure de liaison et de vérification d'un mot.
* 
* \return vrai si un mot a été trouvé.
*/
int proposerMot(void)
{
	char mot[20];
	int ok;
	demanderCoord(format);
	formerMot(mot,format);
	ok = supprimerMot(mot,format);
	if(ok)
	{
		rearrangerGrille(format);
		printf("Félicitation vous avez trouvé un mot !\n");
		sleep(3);
	}
	if(verifFinPartie())
	{
		nbAstuce++;
		score++;
		printf("Félicitation vous avez trouvé tout les mots!\n");
		sleep(3);		
	}
	
	return ok;
}



/**
* \fn int verifFinPartie(void)
* \brief Vérifie si tout les mots de la grille ont étés trouvés
*
* \return Vrai si tout les mots ont étés trouvés
*/
int verifFinPartie(void)
{
	int check=1;
	t_mot structMot;

	en_tete();
	while(!hors_liste() && !liste_vide())
	{
		valeur_elt(&structMot);
		if(structMot.etat == FALSE)
			check=0;
		suivant();
	}

	return check;

}



/**
* \fn void astuce(void)
* \brief Procédure d'ajout d'un nouvel indice.
* 
* Révèle la prochaine lettre du mot dont toutes les lettres n'ont pas étés decouvertes.
* Cette fonction ne change pas l'état du mot (si il est trouvé ou pas), et donc l'utilisateur
* doit rentrer les mots même si ceux-si sont déjà entièrement affichés
* 
*/
void astuce(void)
{

	int ok=0;

	if(nbAstuceUtilise < nbAstuce)
		ok=1;

	int nbMini;
	int first;
	t_mot structMot;


	if(ok==1)
	{

		en_tete();
	

		// On cherche le nombre de lettre à reveler le plus petit

		valeur_elt(&structMot);
		nbMini=structMot.nb_revele;
		suivant();


		while(!hors_liste())
		{
			valeur_elt(&structMot);
			if(structMot.nb_revele!=(int)strlen(structMot.mot))
			{
		
				if(nbMini>structMot.nb_revele)
				{
					nbMini=structMot.nb_revele;
				}

			}		

			suivant();
		}
	
		// On chercher le mots ayant le moins de lettres révélées
		en_tete();
		valeur_elt(&structMot);

		printf("nbMini: %i\n",nbMini);
	
		while(!hors_liste() && structMot.nb_revele!=nbMini || !hors_liste() && structMot.nb_revele>=(int)strlen(structMot.mot) )
		{
		
			suivant();
			valeur_elt(&structMot);
		
		}

		if(hors_liste())
			en_queue();

		printf("nbrev1: %i\n",structMot.nb_revele);
		printf("mot: %s\n",structMot.mot);

	
		// On incrémente le nombre de lettres à afficher
		valeur_elt(&structMot);
		structMot.nb_revele++;
		modif_elt(structMot);

		printf("nbrev2: %i\n",structMot.nb_revele);

		nbAstuceUtilise++;
	
	}
	else
	{
		printf("Vous ne pouvez pas demander d'astuces !\n");
		sleep(3);
	}


}




/**
* \fn void recommencer(void)
* \brief le(s) mot(s) proposé(s) et les lettres obtenus par les astuces sont effacés.
*/
void recommencer(void)
{
	t_mot structMot;

	if(modeDeJeu==1)
	{
		en_tete();
		while(!hors_liste())
		{
			valeur_elt(&structMot);
			structMot.nb_revele=0;
			structMot.etat=FALSE;
			modif_elt(structMot);
			suivant();
		}
		for(int i; i<format; i++) 
			strcpy(grille[i],grilleOri[i]);
	}
	else if(modeDeJeu==2)
	{
		en_tete();
		while(!hors_liste())
		{
			valeur_elt(&structMot);
			structMot.nb_revele=0;
			structMot.etat=FALSE;
			modif_elt(structMot);
			suivant();
		}
		//for(int i; i<format; i++) 
		//	strcpy(grille[i],grilleOri[i]);
	}
	en_tete();

}


/**
* \fn void jouer(int format)
* \brief Procédure gérant l'affichage du menu de jeu et la navigation entre les options.
* 
* \param Format Entier représentant le forma de la grille de jeu.
*/
void jouer(int format)
{
	int choix;
	
	
	do{
		system("clear");
		
		afficherGrille(format);
		printf("\n"); 
		
		indenter(1); printf("Mots à trouver : \n");
		afficherEtatMots();

		indenter(1); printf("1 - Proposer un mot    \n");
		indenter(1); printf("2 - Recommencer        \n");
		indenter(1); printf("3 - Demander une astuce\n");
		indenter(1); printf("4 - Quitter            \n");
		indenter(1); printf("\nVotre choix : ");
		
		
		fflush(stdin);
		scanf("%i",&choix);
		switch(choix)
		{

			case 1: proposerMot(); break;
			case 2: recommencer(); break;
			case 3: astuce(); break;
			case 4: break;
			default: 
				printf("\nVotre choix doit être compris entre 1 et 4.\n");
				sleep(1);
		}

	}while(choix !=4);
}

/**
* \fn void selectNiv(void)
* \brief Procédure gérant l'affichage du menu de de sélection de niveau et la navigation entre les options.
* 
*/
void selectNiv(void)
{

	char choix[5];
	
	printf("\nJouer ? (oui/non) : ");
	
	fflush(stdin);
	scanf("%s",choix);
	while(strcmp(choix,"non") !=0 && strcmp(choix,"oui") !=0)
	{
		printf("Incorrecte. Vérifier l'orthographe du mot: entrez 'oui' ou 'non' : ");
		fflush(stdin);
		scanf("%s",choix);
	}
	if(strcmp(choix,"oui") == 0)
		menuGrille();
	
}



//affichage de la totalité des niveau en fonction du format de la grille
/**
* \fn void menuGrille()
* \brief Procédure gérant l'affichage des niveaux disponibles et la navigation entre les options.
* 
* L'affichage se fait en fonction du format de la grille

*/
void menuGrille()
{
	int choix;
	char check[5]; 
	char p;
	int nivMin,nivMax;
	nbAstuceUtilise = 0;
	/*char tabMots[TAILLE_MOT_MAX];
	char tabGrille[50];*/

	
	do{	int iNiveau=0;
		system("clear");

		do
		{
			system("clear");		
			printf("Sur quel type de grille voulez-vous jouer ? (Compris entre 2 et 7)\n");
			scanf("%i",&choix);			

			if(choix<2 || choix>7)
				printf("veillez entrer un nombre compris entre 2 et 7\n"); 
				
		}while(choix<2 || choix>7);

		format=choix;

		//system("clear");
		printf("Voici la liste de niveaux: \n");	
		printf("\nGrille %ix%i :\n",choix,choix);

		for(int i=2; i<8; i++)
		{
			for(int j=2; j<5; j++)
			{
				iNiveau++;
				if(i==choix)
					printf("\tNiveau %i (Grille %ix%i n°%i)\n",iNiveau,choix,choix,j-1);
			}
		}
	
		printf("Voulez-vous restez sur ce type de grille ? (oui/non/quitter)\n");
		scanf("%s",check);
		

	}while(strcmp(check,"oui")!=0 && strcmp(check,"quitter")!=0);
	if(strcmp(check,"oui") == 0)
	{
		//jouer(3);
		printf("Quel niveau charger ?\n");
		scanf("%i",&niveau);
				
		initPartie(); //Charger partie
	}

	

}



/**
* \fn void creerGrille(void)
* \brief Créer une grille a partir des mots donnés par l'utilisateur.
*/
void creerGrille(void)
{	
	vider_liste();
	viderGrille(TMAX);

	int nbMots=0;
	int nbLettres;
	int tailleMot;
	int conditionLettre;
	int form;
	int choix;
	char tabMots[20][TAILLE_MOT_MAX];

	modeDeJeu=2;
	
	do
	{	system("clear");
		printf("Quel format aura la grille ? (Entre 2 et 5)\n");
		scanf("%i",&form);

	}while(form<2 || form>5);

	format=form;	

	printf("Cb de mots voulez-vous rentrer ?\n");
	scanf("%i",&nbMots);
	


	do{
		nbLettres=0;
		conditionLettre=1;
		printf("\n");
		for(int i=0; i<nbMots; i++)
		{
			printf(" - ");	
			scanf("%s",tabMots[i]);
			nbLettres=nbLettres+(int)strlen(tabMots[i]);
		}

		for(int i=0; i<nbMots; i++)
		{
			tailleMot=(int)strlen(tabMots[i]);
			for(int j=0; j<tailleMot; j++)
			{
				if(tabMots[i][j]>64 && tabMots[i][j]<91 || tabMots[i][j]>96 && tabMots[i][j]<123)
					tabMots[i][j]=toupper(tabMots[i][j]);
				else
					conditionLettre=0;
			}
		}

	}while( nbLettres != (form*form) || conditionLettre!=1);




	for(int i=0; i<nbMots; i++)
		ajouterMot(tabMots[i]);


	//melangerMots(form,tabMots);
	for(int i; i<format; i++) 
		strcpy(grilleOri[i],grille[i]);
	jouer(form);


}

