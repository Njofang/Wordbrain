#include <stdio.h>
#include "includes/wordbrain.h"
#include <time.h>


 /*
 *
 * ATTENTION, ZONE DE DANGER
 * VOUS RISUQEZ DE NE PAS COMPRENDRE LE CODE QUI SUIT
 * POUR VOTRE SANTE, FERMEZ CETTE FENÊTRE
 *
 */


void print(char* grille, int format)
{
	int offset;
	printf("\n");
	for(int i=0; i<format; i++)
	{
		for(int j=0; j<format; j++)
		{
			offset = i * format + j;
			if(isalpha(grille[offset]))
				printf("%c ",grille[offset]);
			else
				printf(". ");
		}
		printf("\n");
	}
	printf("\n");
}

int between(int n, int border1, int border2)
{
	return (n >= border1 && n <= border2);
}


int abs(int n)
{
	if(n >= 0)
		return n;
	else
		return -n;
}
int signe(int n)
{
	if(n >= 0) return 1;
	else return -1;
}

typedef enum {e_libre,e_correcte,e_occupe,e_conflit}t_etat;

void resoudreConflits(char* primaire,char* secondaire, int format)
{
	t_etat* colonneEtat;
	int colonne, caseConflit, caseLibre, i;
	int pasDeConflit, obstacle;
	int dist;
	char temp;
	int offset1,offset2;
	
	colonneEtat = (t_etat*) malloc(format*sizeof(t_etat));
	
	colonne=0;
	while(colonne<format) //Parcours des colonnes
	{
		//Actualisation des états
		for(i=0; i<format; i++)
		{
			offset1 = i * format + colonne;
			if(isalpha(primaire[offset1]) && isalpha(secondaire[offset1]))
				colonneEtat[i] = e_conflit;
			else if(!isalpha(primaire[offset1]) && isalpha(secondaire[offset1]))
				colonneEtat[i] = e_correcte;
			else if(isalpha(primaire[offset1]) && !isalpha(secondaire[offset1]))
				colonneEtat[i] = e_occupe;
			else if(!isalpha(primaire[offset1]) && !isalpha(secondaire[offset1]))
				colonneEtat[i] = e_libre;
			else 
			{
				printf("Erreur : etat colonne\n");
				sleep(2);
			}
		}
		
		//Prendre une case en conflit
		pasDeConflit = TRUE;
		for(i=0; i<format && pasDeConflit; i++)
		{
			if(colonneEtat[i] == e_conflit)
			{
				caseConflit = i;
				pasDeConflit = FALSE;
			}
		}
		
		if(pasDeConflit)
		{
			colonne++;
		}
		else
		{
			//Chercher la case libre la plus proche;
			dist = format;
			caseLibre = -1;
			for(i=0; i<format; i++)
			{
				if(colonneEtat[i] == e_libre)
				{
					if(abs(caseConflit - i) < dist)
					{
						caseLibre = i;
						dist = abs(caseConflit - i);
					}
				}
			}
			if(caseLibre == -1)
			{
				printf("Erreur : pas de case libre\n");
				sleep(2);
			}
			else
			{
				//Se déplacer depuis la case libre vers la case de conflit
				//Pour vérifier s'il y a des obstacles
				obstacle = FALSE;
				for(i=caseLibre; i!=caseConflit && !obstacle; i+=signe(caseConflit-caseLibre))
				{
					if(colonneEtat[i] == e_correcte || colonneEtat[i] == e_conflit)
					//Rencontre d'un obstacle
					{
						obstacle = TRUE;
						//Permuter l'obstacle (case i) avec la case libre
						offset1 = caseLibre * format + colonne;
						offset2 = i * format + colonne;
						
						temp = secondaire[offset2];
						secondaire[offset2] = secondaire[offset1];
						secondaire[offset1] = temp;
					}
				}
				
				if(!obstacle)
				{
					//Permuter la case de conflit avec la case libre
						offset1 = caseLibre * format + colonne;
						offset2 = caseConflit * format + colonne;
						
						temp = secondaire[offset2];
						secondaire[offset2] = secondaire[offset1];
						secondaire[offset1] = temp;
				}
				
			}
		}
	}
	printf("Conflit résolu\n");
	free(colonneEtat);
}



void genererGrille()
{
	int format;
	
	char* grillePrim;
	char* grilleSnd;
	
	int* casesOccupees;
	int* casesRestantes; //indices colonnes
	
	int* casesDispos;
	int nbCasesDispos;
	int numCase;
	int randChoix;
	
	
	int nombreMots = 0;
	t_mot structMot;
	int longueurMot;
	int k;
	int x,y,i,j;
	int offset;
	
	int ok = FALSE;
	int bloque;
	int position;
	int colBord1,colBord2,okBord;
	
	srand(time(NULL));
	
	//Initialisation des matrices et tableaux
	do{
		printf("format : ");
		scanf("%i",&format);
	}while(format < 1);
	
	grillePrim = (char *)malloc(format*format*sizeof(char));
	grilleSnd = (char *)malloc(format*format*sizeof(char));
	casesOccupees = (int *)malloc(format*sizeof(int));
	casesRestantes = (int *)malloc(format*sizeof(int));
	casesDispos = (int *)malloc(9*sizeof(int));
	
	for(i=0; i<format; i++)
	{
		for(j=0; j<format; j++)
		{
			offset = i * format + j;
			grillePrim[offset] = ' ';
			grilleSnd[offset] = ' ';
		}
		casesOccupees[i] = 0;
		casesRestantes[i] = format;
	}
		
	//Initialisation de la liste de mots
	init_liste();
	ajouterMot("CHAT");
	nombreMots++;
	ajouterMot("ABRIS");
	nombreMots++;
	ajouterMot("POIVRON");
	nombreMots++;
	ajouterMot("KOALA");
	nombreMots++;
	ajouterMot("PALE");
	nombreMots++;
	

	//Initialisation du premier mot
	if(!liste_vide())
	{
		en_tete();
		position = 0;
		
		valeur_elt(&structMot);
		longueurMot = strlen(structMot.mot);
		x = rand()%format;
		y = rand()%format;
		
		colBord1 = 0;
		colBord2 = format-1;
	
		bloque = FALSE;
		k=0;
		while(k<longueurMot)
		{
			if(bloque)
			{
				printf("BLOQUE !\n");
				k=0;
				//vider grille
				for(i=0; i<format; i++)
				{
					casesOccupees[i] = 0;
					for(j=0; j<format; j++)
					{
						offset = i * format + j;
						grillePrim[offset] = ' ';
					}
				}
				x = rand()%format;
				y = rand()%format;
				colBord1 = 0;
				colBord2 = format-1;
				do{
					okBord = TRUE;
					if(casesRestantes[colBord1]-casesOccupees[colBord1] <= 0)
					{
						colBord1 ++;
						okBord = FALSE;
					}
					if(casesRestantes[colBord2]-casesOccupees[colBord2] <= 0)
					{
						colBord2 --;
						okBord = FALSE;
					}
				}while(!okBord);
				bloque = FALSE;
			}
			
			
			offset = x * format + y;
			grillePrim[offset] = structMot.mot[k];
			casesOccupees[y] ++;
			//maj des bordures
			do{
				okBord = TRUE;
				if(casesRestantes[colBord1]-casesOccupees[colBord1] <= 0)
				{
					colBord1 ++;
					okBord = FALSE;
				}
				if(casesRestantes[colBord2]-casesOccupees[colBord2] <= 0)
				{
					colBord2 --;
					okBord = FALSE;
				}
			}while(!okBord);
			
			print(grillePrim,format);
			
			k++;
			//calcule de la prochaine coordonnée
			if(k<longueurMot)
			{
				nbCasesDispos = 0;
				for(j=-1; j<=1; j++)
				{
					for(i=-1; i<=1; i++)
					{
						offset = (x+i) * format + (y+j);
						if(!(i==0 && j==0) && between(x+i,0,format-1) && between(y+j,0,format-1)  && grillePrim[offset] == ' ')
						{
							if((casesRestantes[y+j] - casesOccupees[y+j] -(position<nombreMots-1 && y+j!=colBord1 && y+j!=colBord2)) > 0 && casesOccupees[y+j] < 3)
							{
								numCase = (y+j)*format + x+i;
								casesDispos[nbCasesDispos] = numCase;
								nbCasesDispos ++;
							}
						}
					}
				}
				/*-----------------------------------*/
				if(nbCasesDispos > 0)
				{
					randChoix = rand()%nbCasesDispos;
					numCase = casesDispos[randChoix];
					x = numCase%format;
					y = numCase/format;
				}
				else
				{
					bloque = TRUE;
				}
			}
		}//fin while
		for(i=0; i<format; i++)
		{
			casesRestantes[i] -= casesOccupees[i];
			casesOccupees[i] = 0;
		}
		
		suivant();
		
		
		//Routine de génération
		while(!hors_liste())
		{
			printf("------------------------------------------------------------\n");
			position ++;
			
			valeur_elt(&structMot);
			longueurMot = strlen(structMot.mot);
			
			ok = FALSE;
			while(!ok)
			{
				x = rand()%format;
				y = rand()%format;
				if(casesRestantes[y] > 0)
					ok = TRUE;
			}
	
			bloque = FALSE;
			k=0;
			while(k<longueurMot)
			{
				if(bloque)
				{
					printf("BLOQUE !\n");
					k=0;
					//vider grille
					for(i=0; i<format; i++)
					{
						casesOccupees[i] = 0;
						for(j=0; j<format; j++)
						{
							offset = i * format + j;
							grilleSnd[offset] = ' ';
						}
					}
					ok = FALSE;
					while(!ok)
					{
						x = rand()%format;
						y = rand()%format;
						if(casesRestantes[y] > 0)
							ok = TRUE;
					}
					colBord1 = 0;
					colBord2 = format-1;
					do{
						okBord = TRUE;
						if(casesRestantes[colBord1]-casesOccupees[colBord1] <= 0)
						{
							colBord1 ++;
							okBord = FALSE;
						}
						if(casesRestantes[colBord2]-casesOccupees[colBord2] <= 0)
						{
							colBord2 --;
							okBord = FALSE;
						}
					}while(!okBord);
					bloque = FALSE;
				}
			
			
				offset = x * format + y;
				grilleSnd[offset] = structMot.mot[k];
				casesOccupees[y] ++;
				
				//maj des bordures
				do{
					okBord = TRUE;
					if(casesRestantes[colBord1]-casesOccupees[colBord1] <= 0)
					{
						colBord1 ++;
						okBord = FALSE;
					}
					if(casesRestantes[colBord2]-casesOccupees[colBord2] <= 0)
					{
						colBord2 --;
						okBord = FALSE;
					}
				}while(!okBord);
			
				
				printf("Grille Prim\n");
				print(grillePrim,format);
				printf("Grille Second\n");
				print(grilleSnd,format);
				
				k++;
				//calcule de la prochaine coordonnée
				if(k<longueurMot)
				{
					nbCasesDispos = 0;
					for(j=-1; j<=1; j++)
					{
						for(i=-1; i<=1; i++)
						{
							offset = (x+i) * format + (y+j);
							if(!(i==0 && j==0) && between(x+i,0,format-1) && between(y+j,0,format-1)  && grilleSnd[offset] == ' ')
							{
								if((casesRestantes[y+j] - casesOccupees[y+j] -(position<nombreMots-1 && y+j!=colBord1 && y+j!=colBord2)) > 0 && casesOccupees[y+j] < 3)
								{
									numCase = (y+j)*format + x+i;
									casesDispos[nbCasesDispos] = numCase;
									nbCasesDispos ++;
								}
							}
						}
					}
					/*-----------------------------------*/
					if(nbCasesDispos > 0)
					{
						randChoix = rand()%nbCasesDispos;
						numCase = casesDispos[randChoix];
						x = numCase%format;
						y = numCase/format;
					}
					else
					{
						bloque = TRUE;
					}
				}
			}//fin while
			for(i=0; i<format; i++)
			{
				casesRestantes[i] -= casesOccupees[i];
				casesOccupees[i] = 0;
			}
			
			//Résolution de conflit
			resoudreConflits(grillePrim,grilleSnd,format);
			
			//Fusion et nettoyage
			for(i=0; i<format; i++)
			{
				for(j=0; j<format; j++)
				{
					offset = i * format + j;
					if(!isalpha(grillePrim[offset]) && isalpha(grilleSnd[offset]))
					{
						grillePrim[offset] = grilleSnd[offset];
						grilleSnd[offset] = ' ';
					}
				}
			}
			
			suivant();
			
		}//fin routine
		
		printf("------------------------------------------------------------\n");
		printf("Grille Finale\n");
		print(grillePrim,format);
	}
	
	

	free(grillePrim);
	free(grilleSnd);
	free(casesOccupees);
	free(casesRestantes);
	free(casesDispos);
}

int main()
{
	printf("Hello\n");
	genererGrille();
	
	return 0;
}