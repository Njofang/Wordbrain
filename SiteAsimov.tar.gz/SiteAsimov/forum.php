<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="UTF-8"> 
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/screen.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/style.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePC.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePort.css">
		<link href="Accueil%20ASIMOV_fichiers/css.css" rel="stylesheet">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<link rel="icon" href="ASIMOV_fichiers/Logo_ASIMOV.png">

	
    
    </head>
		
					
		
		
		<title>Forum</title>
	</head>
<!--[if lt ie 7]><link rel="stylesheet" type="text/css" media="screen" href="ie-win.css" /><![endif]-->
</head>
<body id="babout">
<div id="header">
	<div class="contenair_header">
			<!-- header -->
			<div class="header">
				
				<!-- Menu PC -->
				<div class="name"><a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/" class="text_menu"><img width="50%" src="ASIMOV_fichiers/Logo_ASIMOV.png" alt="Logo Asimov"></a></div>
				<div class="menuPC">

					
					<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/news.php" class="text_menu">News</a>
					<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/forum.php" class="text_menu">Forum</a>
					<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/connexion.php" class="text_menu">Connexion</a>
					<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/inscription.php" class="text_menu">S'inscrire</a>

				</div>

				<!-- Menu Portable -->
				<div class="menuPort">
					<div class="button">≡</div>
					<div class="sous_menu">
						<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/" class="text_menuPort">Accueil A.S.I.M.O.V.</a>
						<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/news.php" class="text_menu">News</a>
						<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/forum.php" class="text_menu">Forum</a>
						<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/connexion.php" class="text_menu">Connexion</a>
						<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/inscription.php" class="text_menu">S'inscrire</a>
					</div>
				</div>
			

			</div>

      <h4>Liste des Forums</h4>
      <dl>
        <dt>Commentaire</dt>
        <dd> Discussion sur les activités ASIMOV. <em> Disponible sur <a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/"  title="SimplyGold">Accueil</a>. 
          L'assosiation ASIMOV (Association des Super Informaticiens
 du Mans Officieusement Vitamine) permet l'organisation de rencontre 
avec d'anciens étudiants du département Informatique en vue de faciliter
 de recherche d'emplois ou de stages en entreprise. </em> </dd>
        <dt>Divertissement</dt>
        <dd> <em>Une caféteria est mise a disposition au rez de chaussé de l'institut Claude Chappe..</em></dd>
        <dt>Actualité</dt>
        <dd> <em>Nous organisons des tournois de jeux tel que League of Legends. Suivant un plannig défini <del>e</del>. </em></dd>
        <dt>Etude</dt>
        <dd> <em>Comment intégrer l'association?</em></dd>
        <dt>Jeux vidéo</dt>
        <dd class="last"> <em>Nous organisons des tournois de jeux tel que League of Legends.</em></dd>
      </dl>
      <h6>Autres Informations</h6>
      <blockquote>
        <p>Où sommes nous ? <cite>&mdash; <abbr title="Invisible Pink Unicorn"></abbr></cite></p>
      </blockquote>
      <pre><code>20 Avenue René Laennec,72000 Le Mans</code></pre>
    </div>
  </div>
  



</div>

			
			<div class="footer">
				<span></span>
				<span>Site ASIMOV pour un TP</span>
			</div>
		
			</div>


</body></html>
