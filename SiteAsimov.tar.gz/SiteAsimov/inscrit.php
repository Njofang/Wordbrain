<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="UTF-8"> 
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/style.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePC.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePort.css">
		<link href="ASIMOV_fichiers/css.css" rel="stylesheet">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<link rel="icon" href="ASIMOV_fichiers/Logo_ASIMOV.png">

		<title>Inscription Réussie A.S.I.M.O.V.</title>
	</head>
<body>

<?php
	session_start();
	if ($_SESSION['cnx']=='true')
		require 'header_connect.php';
	else
		require 'header.php';
?>

<?php include('./php_lib/includeheadhtml.php') ?>
<div class="ecart">
  <?php

       // pour gagner du temps on peut utiliser la fonction extract($_POST) 
       // vérifie si il y a des valeurs et transforme le tableau associatif $_POST en variables
      if (extract($_POST)){
            
      		//paramètre de connexion à la base de données
			include_once('./php_lib/connect_bdd.php');
			connect($Connect);
			//affichage d ’un message d’erreur si la connexion a été refusée
			if (!$Connect) {
				echo "Connexion à la base impossible";
			} 
			else {
			//Ecriture de la requête en SQL 
			//$myquery='INSERT INTO `VR_WILLIAM_utilisateur` VALUES ('$donnees['id_utilisateur']', '$donnees['prenom']', '$donnees['nom']', '$donnees['login']', '$donnees['password']', '$donnees['mail']', '$donnees['date_naissance']', '$donnees['promotion']', '$donnees['id_statut']');';
			$param ='INSERT INTO VR_WILLIAM_utilisateur (prenom, nom, login,password, mail, date_naissance, promotion) VALUES (?,?,?,?,?,?,?)';
			$stmt = mysqli_prepare($Connect,$param );
			mysqli_stmt_bind_param($stmt,"sssssss",  $_POST['prenom'], $_POST['nom'], $_POST['login'], $_POST['password'], $_POST['mail'], $_POST['date_naissance'], $_POST['promotion']);
			if(mysqli_stmt_execute($stmt)) echo("Merci de votre inscription !");
			else die("erreur : ".mysqli_error($Connect));
			
			//Envoi de la requête
			$result = $Connect->query($myquery);

            mysqli_free_result($result);

			  
			}
			//on ferme la connexion
			mysqli_close($Connect);			
		}    
  ?>
  </div>
  
<!-- appel du pied de page, identique pour toutes les page du site -->
<?php include('./php_lib/includefooterhtml.php') ?> 
<?php require 'footer.php'; ?>
</body></html>
