<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="UTF-8"> 
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/style.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePC.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePort.css">
		<link href="ASIMOV_fichiers/css.css" rel="stylesheet">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<link rel="icon" href="ASIMOV_fichiers/Logo_ASIMOV.png">

		<title>Déconnexion A.S.I.M.O.V.</title>
	</head>
<body>

<?php
require 'header.php';
include('./php_lib/includeheadhtml.php') ?>
<div class="ecart">
	<?php
		session_start();
		$_SESSION = array();
		session_destroy();
		unset($_SESSION);

		echo "Vous avez été déconnecté avec succès !";
	?>
</div>
<?php include('./php_lib/includefooterhtml.php') ?> 
<?php require 'footer.php'; ?>

</body></html>
