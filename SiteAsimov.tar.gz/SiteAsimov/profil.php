<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="UTF-8"> 
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/style.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePC.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePort.css">
		<link href="ASIMOV_fichiers/css.css" rel="stylesheet">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<link rel="icon" href="ASIMOV_fichiers/Logo_ASIMOV.png">

		<title>Inscription Réussie A.S.I.M.O.V.</title>
	</head>
<body>

<?php
	session_start();
	if ($_SESSION['cnx']=='true')
		require 'header_connect.php';
	else
		require 'header.php';
?>

<div class="ecart">

<?php include('./php_lib/includeheadhtml.php') ?>
<?php
	echo "Voici vos informations : <br><br>";
	echo "Pseudo :<br>";
  	echo "<b>".$_SESSION['login']."</b><br><br>";
  	echo "Mot de passe :<br>";
  	echo "<b>".$_SESSION['password']."</b><br><br>";
  	echo "Nom :<br>";
	echo "<b>".$_SESSION['nom']."</b><br><br>";
  	echo "Prénom :<br>";
	echo "<b>".$_SESSION['prenom']."</b><br><br>";
	echo "Date de naissance :<br>";
	echo "<b>".$_SESSION['date_naissance']."</b><br><br>";
	echo "Promotion :<br>";
	echo "<b>".$_SESSION['promotion']."</b><br><br>";
  	echo "Adresse e-mail :<br>";
  	echo "<b>".$_SESSION['mail']."</b><br><br>";
	echo "Statut au sein du site ASIMOV :<br>";
  	echo "<b>".$_SESSION['id_statut']."</b><br><br>";

?>
<?php require 'footer.php'; ?>
</div>
</body></html>
