
Noms: 
	-William Njofang
	-Benjamin Nouvelière

Adresse du site:

	http://info.univ-lemans.fr/~l3info035/SiteAsimov/

Bases de données:

	VR_WILLIAM_event_un
	VR_WILLIAM_event_deux
	VR_WILLIAM_news
	VR_WILLIAM_page
	VR_WILLIAM_un
	VR_WILLIAM_participation_un	
	VR_WILLIAM_participation_deux
	VR_WILLIAM_response
	VR_WILLIAM_publication
	VR_WILLIAM_status
	VR_WILLIAM_utilisateur


Informations:

	Banières des l1 récupérée.