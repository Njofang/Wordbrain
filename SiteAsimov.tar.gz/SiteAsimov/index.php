<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="UTF-8"> 
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/style.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePC.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePort.css">
		<link href="ASIMOV_fichiers/css.css" rel="stylesheet">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<link rel="icon" href="ASIMOV_fichiers/Logo_ASIMOV.png">

		<title>Accueil A.S.I.M.O.V.</title>
	</head>
<body>

<?php
	session_start();
	if ($_SESSION['cnx']=='true')
		require 'header_connect.php';
	else
		require 'header.php';
?>

<div class="slideshow">
<ul>
<li><a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/index.php"><img src="ASIMOV_fichiers/bienvenue.gif"></a></li>
<li><a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/news.php"><img src="ASIMOV_fichiers/cafe.jpg"></a></li>
<li><a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/forum.php"><img src="ASIMOV_fichiers/jeu.jpg"></a></li>
<li><a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/news.php"><img src="ASIMOV_fichiers/evenement.jpg"></a></li>
<li><a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/forum.php"><img src="ASIMOV_fichiers/diplome1.jpg"></a></li>
</ul>
<div class="barre_progression"></div>
</div>

			<h2 class="col"></br></br>NOTRE ACTUALITE </h2>
			
			 <ul class="nav">
  <li><a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/prochainement.php">Contact</a></li>
  <li><a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/prochainement.php">About</a></li>
</ul> 

<?php require 'footer.php'; ?>

</body></html>
