<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="UTF-8"> 
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/style.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePC.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePort.css">
		<link href="ASIMOV_fichiers/css.css" rel="stylesheet">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<link rel="icon" href="ASIMOV_fichiers/Logo_ASIMOV.png">

		<title>Inscription A.S.I.M.O.V.</title>
	</head>
<body>

<?php
	session_start();
	if ($_SESSION['cnx']=='true')
		require 'header_connect.php';
	else
		require 'header.php';
?>
<?php include('./php_lib/includeheadhtml.php') ?>
		<!-- Contenu de la page -->
		<div class="container_principal">
			<div class="container">
				
			
				<a href="prochainement.html" class="section section_news">
					<div class="section_news_animation">
						<img src="ASIMOV_fichiers/trophee.jpg" alt="Ekko dans League of Legends" class="section_news_image">	
						<div>
							Résultat tournoi 
						</div>
					</div>
					<div class="info_news">Résultat du concours du 09/12/2017</div>
				</a>

				<a href="prochainement.html" class="section section_news">
					<div class="section_news_animation">
						<img src="ASIMOV_fichiers/veau.jpg" alt="Blanquette de veau" class="section_news_image">
						<div>
							Plat à la caféteria
						</div>
					</div>
					<div class="info_news">Des plats sont maintenant disponible avec Formule...</div>
				</a>

				<a href="prochainement.html" class="section section_news">
					<div class="section_news_animation">
						<img src="ASIMOV_fichiers/league.jpeg" alt="Ekko dans League of Legends" class="section_news_image">
						<div>
							Tournoi League of Legends
						</div>
					</div>
					<div class="info_news">Tournoi League of Legends : Comment s'inscrire, Prix d'inscription... </div>
				</a>

				<a href="prochainement.html" class="section section_news">
					<div class="section_news_animation">
						<img src="ASIMOV_fichiers/tasse-de-cafe.png" alt="Café" class="section_news_image">
							<div>
								Des nouveaux café !
							</div>
					</div>
					<div class="info_news">Des nouveaux café disponible a la cafétéria... </div>
				</a>


			</div>
		</div>
			
<?php require 'footer.php'; ?>

</body></html>

