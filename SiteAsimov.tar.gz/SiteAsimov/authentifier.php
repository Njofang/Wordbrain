<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
		<meta charset="UTF-8"> 
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/style.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePC.css">
		<link rel="stylesheet" type="text/css" href="ASIMOV_fichiers/stylePort.css">
		<link href="ASIMOV_fichiers/css.css" rel="stylesheet">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
		<link rel="icon" href="ASIMOV_fichiers/Logo_ASIMOV.png">

		<title>Authentification A.S.I.M.O.V.</title>
	</head>
<body>

<?php 
include('./php_lib/includeheadhtml.php') ?>
<div class="ecart">
  <?php

       // pour gagner du temps on peut utiliser la fonction extract($_POST) 
       // vérifie si il y a des valeurs et transforme le tableau associatif $_POST en variables
      if (extract($_POST)){
            
      		//paramètre de connexion à la base de données
			include_once('./php_lib/connect_bdd.php');
			connect($Connect);
			//affichage d ’un message d’erreur si la connexion a été refusée
			if (!$Connect) {
				echo "Connexion à la base impossible";
			} 
			else {
			//Ecriture de la requête en SQL 
			$myquery= 'SELECT * FROM `VR_WILLIAM_utilisateur` WHERE login="'.$login.'" AND password="'.$password.'";';
		
			//Envoi de la requête
			$result = $Connect->query($myquery);
	
			while($donnees = mysqli_fetch_assoc($result))
			{
  				session_start();

  				$_SESSION['id_utilisateur'] = $donnees['id_utilisateur'];
  				$_SESSION['login'] = $donnees['login'];
  				$_SESSION['password'] = $donnees['password'];
  				$_SESSION['nom'] = $donnees['nom'];
  				$_SESSION['prenom'] = $donnees['prenom'];
  				$_SESSION['mail'] = $donnees['mail'];
  				$_SESSION['date_naissance'] = $donnees['date_naissance'];
  				$_SESSION['promotion'] = $donnees['promotion'];
  				$_SESSION['id_statut'] = $donnees['id_statut'];
  				$_SESSION['cnx'] = true;

  				echo "<br/>";
  				echo "<br/>";
  				echo "<br/>";
  				echo "<br/>";
  				echo "Bonjour ";
				echo $_SESSION['login'].",";
    			echo "<br/>";
    			echo "Vous êtes actuellement connecté.";
    			require 'header_connect.php';
			}

			if(mysqli_num_rows($result) == 0){
				require 'header.php';
				echo "<br/>";
				echo "La connexion a échoué, veuillez recommencer !";
			}

            mysqli_free_result($result);

			  
			}
			//on ferme la connexion
			mysqli_close($Connect);			
		}    
  ?>
  </div>
  
<!-- appel du pied de page, identique pour toutes les page du site -->
<?php include('./php_lib/includefooterhtml.php') ?>
<?php require 'footer.php'; ?> 
</body></html>
