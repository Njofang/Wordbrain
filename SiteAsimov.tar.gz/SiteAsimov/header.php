
		<div class="contenair_header">
			<!-- header -->
			<div class="header">
				
				<!-- Menu PC -->
				<div class="name"><a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/" class="text_menu"><img width="50%" src="ASIMOV_fichiers/Logo_ASIMOV.png" alt="Logo Asimov"></a></div>
				<div class="menuPC">

					
					<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/news.php" class="text_menu">News</a>
					<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/forum.php" class="text_menu">Forum</a>
					<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/connexion.php" class="text_menu">Connexion</a>
					<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/inscription.php" class="text_menu">S'inscrire</a>

				</div>

				<!-- Menu Portable -->
				<div class="menuPort">
					<div class="button">≡</div>
					<div class="sous_menu">
						<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/" class="text_menuPort">Accueil A.S.I.M.O.V.</a>
						<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/news.php class="text_menu">News</a>
						<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/forum.php" class="text_menu">Forum</a>
						<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/connexion.php" class="text_menu">Connexion</a>
						<a href="http://info.univ-lemans.fr/~l2info028/SiteAsimov/inscription.php" class="text_menu">S'inscrire</a>
					</div>
				</div>
			

			</div>