<div class="footer">
	<span></span>
	<span>Site réalisé par William Njofang et Benjamin Nouvelière</span>
</div>
