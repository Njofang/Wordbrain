<?php
	echo "</body></html>";
?>