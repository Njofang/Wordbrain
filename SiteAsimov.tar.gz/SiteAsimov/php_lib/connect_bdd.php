<?php
function connect(&$connect){
	$Server="info.univ-lemans.fr";
	$DB="l2info";
	$User="l2infoetu";
	$Pwd="webdyn72";
	//connexion au serveur où se trouve la base de données
	$connect = mysqli_connect($Server, $User, $Pwd, $DB);
	return $connect;
}
?>


			
		