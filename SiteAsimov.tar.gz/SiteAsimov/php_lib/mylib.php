<?php

/* function ordonne(&$min, &$max) :
 *  - prend 2 valeurs par référence
 *  - vérifie que la variable $min est bien la plus petite des deux.
 *  - si ce n'est pas le cas, inverse les valeurs des variables
 */

function ordonne(&$min, &$max) {
	if ($min > $max) {
        $temp = $min;
        $min = $max;
        $max = $temp;
    }
}

?>