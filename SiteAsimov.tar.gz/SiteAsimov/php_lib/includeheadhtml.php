<?php
	echo "<!DOCTYPE html>
		<html>
  			<head>
    			<meta charset=\"utf-8\">
    			<title> Formulaire </title>
    			<link href=\"./css/exo2.css\" rel=\"stylesheet\" media=\"all\">
  			</head>
 
  		<body>";

?>		